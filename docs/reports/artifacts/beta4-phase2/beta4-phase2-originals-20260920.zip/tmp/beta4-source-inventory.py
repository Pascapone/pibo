#!/usr/bin/env python3
"""Beta-4.0 first-party source inventory (read-only, reproducible).

Grundmenge: `git ls-files src packages` (= Index; bei cleanem Worktree = HEAD-Stand).
Filter: nur Quell-Endungen .ts/.tsx/.mts/.cts/.js/.mjs/.cjs/.jsx/.py;
Pfade mit node_modules, /dist/, /generated/, /__generated__/ ausgeschlossen.
Zeilen: physische Zeilen (Byte-Zeilen, wie `wc -l`), inkl. Leer-/Kommentarzeilen.
Separat ausgewiesen: generierte Dateien (*.gen.*, *.generated.*, routeTree*, __generated__)
und colocated Tests (*.test.*) innerhalb von src/packages.

Lauf:  python3 .tmp/beta4-source-inventory.py   (kein Build, keine Runtime)
"""
import pathlib
import subprocess
import collections

EXTS = {".ts", ".tsx", ".mts", ".cts", ".js", ".mjs", ".cjs", ".jsx", ".py"}
EXCLUDE_PARTS = ("node_modules", "/dist/", "/generated/", "/__generated__/")


def is_generated(f: str) -> bool:
    base = pathlib.PurePosixPath(f).name
    return (
        ".gen." in base
        or ".generated." in base
        or base.startswith("routeTree")
        or "__generated__" in f
    )


def is_colocated_test(f: str) -> bool:
    return ".test." in pathlib.PurePosixPath(f).name


def area(f: str) -> str:
    p = pathlib.PurePosixPath(f)
    if p.parts[0] == "src":
        return "src/" + (p.parts[1] if len(p.parts) > 1 else "(root)")
    return "packages/" + (p.parts[1] if len(p.parts) > 1 else "(root)")


def main() -> None:
    files = subprocess.check_output(
        ["git", "ls-files", "src", "packages"], text=True
    ).splitlines()
    rows: collections.Counter[str] = collections.Counter()
    lines: collections.Counter[str] = collections.Counter()
    gen_files = gen_lines = test_files = test_lines = 0
    for f in files:
        if any(part in f for part in EXCLUDE_PARTS):
            continue
        if pathlib.PurePosixPath(f).suffix not in EXTS:
            continue
        try:
            n = sum(1 for _ in open(f, "rb"))
        except OSError:
            continue
        a = area(f)
        rows[a] += 1
        lines[a] += n
        if is_generated(f):
            gen_files += 1
            gen_lines += n
        if is_colocated_test(f):
            test_files += 1
            test_lines += n
    for a in sorted(rows):
        print(f"{a:35s} files={rows[a]:4d} lines={lines[a]:7d}")
    print(f"{'TOTAL src+packages':35s} files={sum(rows.values()):4d}"
          f" lines={sum(lines.values()):7d}")
    print(f"davon generiert: files={gen_files} lines={gen_lines}")
    print(f"davon colocated Tests (*.test.*): files={test_files}"
          f" lines={test_lines}")
    print(f"ohne colocated Tests: files={sum(rows.values()) - test_files}"
          f" lines={sum(lines.values()) - test_lines}")


if __name__ == "__main__":
    main()
