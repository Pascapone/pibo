# Vorbereitete Übergaben – NICHT VERSENDET

Diese Texte zeigen Pascal die späteren Sessionaufträge vor der Freigabe. Sie sind keine ausführbaren Skripte und keine automatische Autorisierung. Profile, Session-IDs und gemeinsam gültiger Basis-Commit werden erst nach Freigabe geprüft beziehungsweise erzeugt.

**Dispatcher-Check:** Pascal hat genau diese Revision freigegeben; Originalinputs sind vollständig und hashgeprüft; Basis ist neu bestätigt; vier getrennte Ergebnisordner; keine bestehenden Sessions wiederverwenden oder anschreiben; keine Implementierungsfreigabe in der Nachricht verstecken.

Die Platzhalter BASIS-SHA und FREIGABE-REFERENZ werden erst beim tatsächlichen Start aufgelöst.

## Session A1

Vorgeschlagener Titel: `Beta 4.0 | A1 Analyse | review-r1`

```text
Pascal hat das Analysepaket review-r1 freigegeben: FREIGABE-REFERENZ.
Dein Auftrag ist ausschließlich A1, Analyse und Dokumentation, keine Implementierung.
Lies zuerst .pibo/planning/beta4-phase2-20260920/review-r1/00-abnahme.md und .pibo/planning/beta4-phase2-20260920/review-r1/01-gemeinsame-regeln.md.
Lies dann .pibo/planning/beta4-phase2-20260920/review-r1/assignments/A1.md, .pibo/planning/beta4-phase2-20260920/review-r1/02-ergebnisvorlage.md und die dort genannten Originalinputs.
Die gemeinsame freigegebene Quellbasis ist BASIS-SHA; verifiziere sie ohne Branchwechsel.
Dein einziger Schreibbereich: .pibo/planning/beta4-phase2-20260920/review-r1/results/A1/.
Erzeuge analysis.md, contracts.md, implementation-plan.md und handoff.md.
Keine Produkt-/Teständerungen, Löschungen, Installationen, Builds, Worktrees, Commits,
Gatewayaktionen, Provideraufrufe oder weiteren Agents. Bei Blockern unabhängige Analyse fortführen.
Abschluss maximal 400 Zeichen mit Paket, Status, handoff.md-Pfad, Basis und Blocker.
Danach stoppen und den gemeinsamen Review abwarten.
```

## Session B1

Vorgeschlagener Titel: `Beta 4.0 | B1 Analyse | review-r1`

```text
Pascal hat das Analysepaket review-r1 freigegeben: FREIGABE-REFERENZ.
Dein Auftrag ist ausschließlich B1, Analyse und Dokumentation, keine Implementierung.
Lies zuerst .pibo/planning/beta4-phase2-20260920/review-r1/00-abnahme.md und .pibo/planning/beta4-phase2-20260920/review-r1/01-gemeinsame-regeln.md.
Lies dann .pibo/planning/beta4-phase2-20260920/review-r1/assignments/B1.md, .pibo/planning/beta4-phase2-20260920/review-r1/02-ergebnisvorlage.md und die dort genannten Originalinputs.
Die gemeinsame freigegebene Quellbasis ist BASIS-SHA; verifiziere sie ohne Branchwechsel.
Dein einziger Schreibbereich: .pibo/planning/beta4-phase2-20260920/review-r1/results/B1/.
Erzeuge analysis.md, contracts.md, implementation-plan.md und handoff.md.
Keine Produkt-/Teständerungen, Löschungen, Installationen, Builds, Worktrees, Commits,
Gatewayaktionen, Provideraufrufe oder weiteren Agents. Bei Blockern unabhängige Analyse fortführen.
Abschluss maximal 400 Zeichen mit Paket, Status, handoff.md-Pfad, Basis und Blocker.
Danach stoppen und den gemeinsamen Review abwarten.
```

## Session C1

Vorgeschlagener Titel: `Beta 4.0 | C1 Analyse | review-r1`

```text
Pascal hat das Analysepaket review-r1 freigegeben: FREIGABE-REFERENZ.
Dein Auftrag ist ausschließlich C1, Analyse und Dokumentation, keine Implementierung.
Lies zuerst .pibo/planning/beta4-phase2-20260920/review-r1/00-abnahme.md und .pibo/planning/beta4-phase2-20260920/review-r1/01-gemeinsame-regeln.md.
Lies dann .pibo/planning/beta4-phase2-20260920/review-r1/assignments/C1.md, .pibo/planning/beta4-phase2-20260920/review-r1/02-ergebnisvorlage.md und die dort genannten Originalinputs.
Die gemeinsame freigegebene Quellbasis ist BASIS-SHA; verifiziere sie ohne Branchwechsel.
Dein einziger Schreibbereich: .pibo/planning/beta4-phase2-20260920/review-r1/results/C1/.
Erzeuge analysis.md, contracts.md, implementation-plan.md und handoff.md.
Keine Produkt-/Teständerungen, Löschungen, Installationen, Builds, Worktrees, Commits,
Gatewayaktionen, Provideraufrufe oder weiteren Agents. Bei Blockern unabhängige Analyse fortführen.
Abschluss maximal 400 Zeichen mit Paket, Status, handoff.md-Pfad, Basis und Blocker.
Danach stoppen und den gemeinsamen Review abwarten.
```

## Session D1

Vorgeschlagener Titel: `Beta 4.0 | D1 Analyse | review-r1`

```text
Pascal hat das Analysepaket review-r1 freigegeben: FREIGABE-REFERENZ.
Dein Auftrag ist ausschließlich D1, Analyse und Dokumentation, keine Implementierung.
Lies zuerst .pibo/planning/beta4-phase2-20260920/review-r1/00-abnahme.md und .pibo/planning/beta4-phase2-20260920/review-r1/01-gemeinsame-regeln.md.
Lies dann .pibo/planning/beta4-phase2-20260920/review-r1/assignments/D1.md, .pibo/planning/beta4-phase2-20260920/review-r1/02-ergebnisvorlage.md und die dort genannten Originalinputs.
Die gemeinsame freigegebene Quellbasis ist BASIS-SHA; verifiziere sie ohne Branchwechsel.
Dein einziger Schreibbereich: .pibo/planning/beta4-phase2-20260920/review-r1/results/D1/.
Erzeuge analysis.md, contracts.md, implementation-plan.md und handoff.md.
Keine Produkt-/Teständerungen, Löschungen, Installationen, Builds, Worktrees, Commits,
Gatewayaktionen, Provideraufrufe oder weiteren Agents. Bei Blockern unabhängige Analyse fortführen.
Abschluss maximal 400 Zeichen mit Paket, Status, handoff.md-Pfad, Basis und Blocker.
Danach stoppen und den gemeinsamen Review abwarten.
```
