# Gemeinsame Regeln – Analysevorlauf A1/B1/C1/D1

**Status: ENTWURF ZUR ABNAHME.** Erst eine ausdrückliche Startnachricht des Dispatchers nach Pascals Freigabe erlaubt die Analyse. Eine Datei, ein Hash oder ein `approved`-Feld allein autorisiert keine Session-Erstellung oder Ausführung.

## 1. Rangfolge und Lesebasis

Lies vor Arbeitsbeginn `00-abnahme.md`, diese Regeln, dein Briefing und den vollständigen `inputs/pibo-beta4-arbeitsplan-v3.md`. Lies außerdem die aktuelle `AGENTS.md` und `GLOSSARY.md` im Repository sowie `inputs/codebase-design/SKILL.md`, `DEEPENING.md` und `DESIGN-IT-TWICE.md`. Für Web/Attachments gilt die aktuelle `DESIGN.md`; die zusätzliche Kopie im Downloadpaket dokumentiert nur den gelieferten Stand und ist keine Pflichtdatei auf dem Host.

Der konkrete Auftrag dieser Runde ist enger als die Umsetzungsanweisungen im v3-Plan: **analysieren, entwerfen und dokumentieren, nicht implementieren.** Innerhalb dieses Auftrags bleiben alle Produktzusagen des Plans erhalten. Die Skill-Anweisung, weitere Subagents zu starten oder alte Tests sofort zu löschen, ist hier nicht autorisiert. B/C/D liefern ihre Alternativen selbst; Tests werden nur zugeordnet.

K07 ist das Core-Attachment-System. Die verworfene MCP-Recherche ist kein Auftrag. Wo Quellen widersprechen, die Abweichung mit Quellen benennen, nicht still durch eine eigene Produktentscheidung ersetzen.

## 2. Basis und sicherer Lesezugriff

Erwarteter Branch: `beta/4.0-plugin-system`. Vorgemerkte Quellrevision: `ece5f18cffe3f96f8f5dd8c241aac1d439c67b9a`. Der Dispatcher bestätigt beim Start den gültigen Commit. Alle vier Berichte müssen dieselbe Basis nennen.

Prüfe zu Beginn und vor Übergabe mit ausschließlich lesenden Mitteln Repositorywurzel, Branch, HEAD und `git status --short`. Falls der Arbeitsbaum geändert ist, nichts verwerfen oder aufräumen. Lies produktive Quellen nach Möglichkeit mit `git show <BASIS>:<pfad>` aus der fixierten Revision; aktuelle Arbeitsbaumabweichungen separat kennzeichnen. Kein Branchwechsel, Reset, Stash, Checkout, Commit oder Worktree-Kommando. Bei fehlendem Git-Zugriff ist die Revisionsprüfung blockiert, nicht bestanden.

Lesende Inventurprogramme aus der Standardbibliothek sind erlaubt, sofern sie keine Projektmodule importieren/ausführen und nur eigene Berichtsdaten erzeugen. Quellcode, Schemas, Tests, Manifeste und bestehende Artefaktmetadaten dürfen gelesen werden. Keine private Produkthistorie, Auth-Dateien, Umgebungssecrets oder echte Nutzerdaten als Testmaterial. Git-Konfiguration/Remote-URLs nicht dumpen.

`dist/`, Tarballs und `node_modules/` sind keine aktuelle Build-Abnahme. Artefaktherkunft, Datum und Bezug zur Basis ausweisen. Ein vorhandener Test ist kein bestandener Test; ein Metafile-Eingang ist nicht gleich tatsächlich ausgelieferter Code. Für Bundlekosten `bytesInOutput`, Worker, Browser und Ressourcen unterscheiden.

## 3. Erlaubte und verbotene Änderungen

Dein einziger Schreibbereich ist `.pibo/planning/beta4-phase2-20260920/review-r1/results/<DEIN-PAKET>/`. Darin dürfen die vier Pflichtberichte und nötige statische Inventur-/Belegdateien liegen. Die Pfade sind workspacebezogen; nicht mit `$PIBO_HOME` verwechseln. Keine symlinkbedingten Pfadausbrüche. Einen vorhandenen eigenen Bericht nur mit klarer Revisionsnotiz aktualisieren; fremde Dateien unangetastet lassen.

Nicht ändern: Produktcode, Testdateien, Manifeste, Lockfiles, Builder, `docs/` samt Indizes/Logs/Ledger, Originalinputs, Briefings, Ausführungsfreigabe oder andere Ergebnisordner. Keine Installationen, Builds, Testläufe mit unbekannten Nebenwirkungen, Server-/Browserstarts, externe Netz-/Provideraufrufe, Gateways oder Deployments. Benötigte Prüfungen als spätere Befehle dokumentieren. Keine weiteren Sessions/Subagents oder Nachrichten an andere Sessions ohne Auftrag.

Fehlt eine Voraussetzung, den konkreten Blocker mit Owner benennen und unabhängige Analyse weiterführen. Kein stiller Ersatz durch private Querimporte oder einen zweiten Store. Nicht auf andere Analysen pollen: alle vier liefern eigenständig; der Dispatcher vermittelt den Review.

## 4. Tiefe Module und Interfaces

Nutze das Pibo-Glossar und die Skill-Begriffe Module, Interface, Implementation, Depth, Seam, Adapter, Leverage und Locality. Depth ist Nutzen pro gelernter Oberfläche, nicht Dateilänge. Keine neue Namenswelt über bestehende Produktbegriffe stülpen.

Jeder Vertragsvorschlag enthält: Zweck/Nicht-Ziele, Owner/Aufrufer, exakte heutige Exporte mit Quellstelle, ausdrücklich vorgeschlagene neue Exporte, vollständige Typen/JSON-Schemas soweit ableitbar, Aufrufbeispiel, Invarianten, Reihenfolge, Ergebnis/Ereignisse, Fehler/Wiederholung, Abbruch/Lifecycle, Daten-/Credential-Scope, Ressourcenbesitz, Kosten und Testfälle. Nicht belegbare Details ausdrücklich offen lassen. Kein vorgeschlagener Typ gilt als implementiert.

Für denselben K07-Referenzfall liefern B/C/D unterschiedliche Entwürfe: eine Annotation wird als Snapshot angehängt, eine lokale fachliche Option verändert ihre Draftrevision, Reload erhält sie, dann wird sie kopiert und gesendet. B minimiert die äußere Lernfläche; C macht den üblichen Plugin-Aufruf einfach; D prüft freies Rendering und den vollständigen Draft-/Sende-Lifecycle. Das sind Alternativen, keine drei neu zu bauenden Frameworks. Bestehende Interfaces bevorzugen; reine Logik braucht nicht automatisch einen Port.

## 5. Funktionsschutz und Belegregeln

Beide Loops-Modi, bestehende Aliasse/Daten, aktive VS-Code-Web-Integration, normale CLI, Core-Webansichten, Sessions/History/Bindings, Auth-Scope, Abbruch und Cleanup bleiben erhalten. Nur die im Plan benannten alten Oberflächen sind zur späteren Entfernung vorgesehen. Bilder und Dateien bleiben echte Medien im Core; Web Annotations verwendet später denselben Attachment-Anschluss als Plugin.

Tests niemals nur wegen alter Namen als wertlos einstufen. Pro Kandidat die bisherige beobachtbare Zusage, den aktiven Produktpfad und den vorgesehenen Nachfolgetest dokumentieren. Änderungen, Löschungen, Skips und Assertion-Abschwächungen sind in dieser Runde verboten. AT-01–AT-22 aus v3 unverändert referenzieren; neue Fälle separat benennen.

Jede tragende Aussage kennzeichnen als `QUELLBELEGT`, `HISTORISCH`, `VORSCHLAG` oder `OFFEN`. Quellen: Repositorypfad, Symbol, Zeilen und Basis-Commit; bei gelieferten Plänen Abschnitt/Anforderungs-ID. Keine aktuelle Beleglage aus einem alten Agentenbericht ableiten. Konkrete Importkanten von nachgewiesenen Zyklen unterscheiden. Messmethode, Ausschlüsse und Grenzen angeben; keine erfundenen Einsparungen.

## 6. Pflichtdokumente und Abschluss

Schreibe genau diese vier Hauptdokumente in deinen Ergebnisbereich:

1. `analysis.md`: Ausgangsstand, Quellen, Inventur, bestätigte Befunde, Risiken und Testzuordnung.
2. `contracts.md`: relevante Interface-Entwürfe beziehungsweise zu erhaltende Verhaltensverträge, Beispiele und offene Fragen an andere Owner.
3. `implementation-plan.md`: zusammenhängende spätere Schritte, Dateirechte, Voraussetzungen, kleine Integrationspunkte, Prüf- und Rücknahmeplan. Noch nichts davon ausführen.
4. `handoff.md`: lesbarer Einstieg mit Links auf die drei Berichte, wichtigsten Ergebnissen, Basis und Blockern. Kein Ersatz für die Fachberichte.

Schema und Pflichtfelder stehen in `02-ergebnisvorlage.md`. Verwende stabile Befund-IDs wie `A1-001` und eindeutige Vertragsanforderungen wie `C1→D: K07/snapshot`. Kein vollständig grünes I0/G1 behaupten. Abschlussstatus `ANALYSE_FERTIG` bedeutet nur: Dokumente vollständig; `BLOCKIERT` benennt fehlende Belege. Offen bleibt die spätere Umsetzung mit Piloten, Tests und Freigabe.

Nach Schreiben und Rücklesen der Dokumente antworte einmal mit höchstens 400 Zeichen:

`<PAKET> ANALYSE_FERTIG | <Pfad zu handoff.md> | Basis <kurzer SHA> | Blocker: <keine oder kurze Angabe>`

Bei unvollständigem Auftrag `BLOCKIERT` statt `ANALYSE_FERTIG`. Danach stoppen. Keine lange Chatzusammenfassung, keine automatische Fortsetzung zu B2/C2/D2.
