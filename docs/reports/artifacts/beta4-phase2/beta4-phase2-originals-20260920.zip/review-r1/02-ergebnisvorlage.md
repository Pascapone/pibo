# Ergebnisvorlage für alle vier Analyse-Sessions

Diese Datei ist eine Vorlage, kein bereits erzeugtes Rechercheergebnis. Alle Pfade unten sind relativ zum jeweiligen `results/A1/`, `results/B1/`, `results/C1/` oder `results/D1/`.

## analysis.md

- Kopf: Paket, Berichtsrevision, Zeitpunkt, Basis-Commit, tatsächlich gelesene Quelle, Branch-/Arbeitsbaumprüfung, Freigabeauftrag.
- Kurzes Fazit in verständlicher Sprache.
- Inventur und geprüfte Einstiegspunkte; Dokumente und Quellcode klar trennen.
- Befundtabelle: ID | Status QUELLBELEGT/HISTORISCH/VORSCHLAG/OFFEN | Problem | konkrete Quelle/Symbol/Zeile/Commit | Nutzen der Änderung | Risiko | betroffener Owner.
- Erhaltensmatrix: bestehende Funktion | aktiver Weg | Testdatei/Testname | noch nötiger Nachweis.
- Messwerte: Grundmenge, Methode, Ausschlüsse, Artefaktherkunft; keine ungemessenen Sollzahlen als Ergebnis.
- Nicht ausgeführte Prüfungen und offene Fragen.

## contracts.md

Je Vertrag: ID/Revision (Entwurf v0), Owner, Aufrufer, Zweck, Nicht-Ziele, heutiger Export mit Beleg, vorgeschlagene Änderung separat, Typen/Schemas, Aufrufbeispiel, verborgene Implementation, Abhängigkeitskategorie/Adapter, Invarianten, Reihenfolge/Parallelität, Fehler/Retry, Abbruch/Cleanup, Daten/Permissions, Ressourcen und Tests.

Bei bestehenden Verträgen, die nur erhalten bleiben: „keine neue Oberfläche vorgeschlagen“ und zu schützende Zusagen angeben. Fragen an andere Worker in Tabelle: ID | Empfänger | benötigte Zusage | betroffene Datei | dadurch blockierter späterer Schritt | unabhängige Arbeit.

K07-Alternativen müssen denselben im gemeinsamen Auftrag beschriebenen Referenzfall behandeln. Keine Signatur eines anderen Workers als bereits freigegeben behaupten.

## implementation-plan.md

Je zusammenhängendem Schritt: Ergebnis | Dateien/Owner | Vorgänger | unverändertes Verhalten | geplante Änderung | Testbeleg vor/nachher | Integrationsübergabe | Rücknahme | Abbruchkriterium.

Mechanische Umzüge von fachlichen Änderungen trennen. Dateien mit mehreren Beteiligten bekommen eine geordnete Übergabe, nicht mehrere Schreib-Owner. Spätere Worktrees/Branches nur vorschlagen, nicht anlegen. Kernbefehle nur dann angeben, wenn im Repository gefunden; sonst als zu klären markieren. Provider-/Browser-/Installationsprüfungen als separat freizugebende Ausführung kennzeichnen.

## handoff.md

```markdown
# Übergabe: <A1/B1/C1/D1> – Analyse
Status: ANALYSE_FERTIG | BLOCKIERT
Revision: 1
Basis: <vollständiger SHA>
Umsetzung ausgeführt: nein
I0/G1-Abnahme: nicht erteilt

## Ergebnisse
[Analyse](analysis.md) · [Verträge](contracts.md) · [Umsetzungsplan](implementation-plan.md)

## Wichtigste Befunde
<3–5 konkrete Befunde mit IDs, keine erneute Vollanalyse>

## Was erhalten bleibt
<relevante Funktionszusagen>

## Abhängigkeiten und Blocker
<Owner, Vertrag/Datei, benötigte Übergabe; oder keine>

## Beleggrenze
<was gelesen/gemessen wurde; welche Tests und Piloten ausdrücklich nicht liefen>

## Nächster freizugebender Schritt
<keine eigenständige Fortsetzung>
```

Die Fachberichte dürfen ausführlich sein; wiederhole denselben Inhalt nicht in allen vier Dateien. Das Übergabedokument soll den Review ermöglichen, ohne die Recherche zu duplizieren.
