# Phase 2 – Vier Analyseaufträge zur Abnahme

**Revision:** review-r1 · **Datum:** 20. September 2026 · **Status: WARTET AUF PASCALS ABNAHME.**

Es wurden für diese Runde keine Sessions erstellt und keine Aufträge an Agents übergeben. Dieses Paket bereitet ausschließlich die Abnahme vor. Das Vorhandensein der Dateien ist keine Startfreigabe.

## 1. Was zur Freigabe steht

Vier getrennte Analyse-Sessions zu A1, B1, C1 und D1. Sie untersuchen den festgelegten Quellstand und liefern konkrete, belegte Entwürfe sowie spätere Umsetzungsschritte. **Kein Produktcode wird geändert, nichts wird gelöscht und kein Pilot wird jetzt implementiert.**

Die vollständige Grundlage ist der unveränderte Gesamtplan [v3 als Markdown](inputs/pibo-beta4-arbeitsplan-v3.md). Diese Fassung ist auf dem Pibo-Host abgelegt; die HTML-Präsentation liegt zusätzlich im Downloadpaket unter `inputs/pibo-beta4-arbeitsplan-v3.html`. Dieser engere Analyseauftrag folgt Pascals aktuellem Wunsch, zunächst die Analysen gemeinsam anzusehen. Er ersetzt nicht die ausführbare A1–D1-Vorbereitung des Gesamtplans. I0 und G1 sind damit nicht bestanden; reine Berichte geben keine Interfaces v1 frei.

## 2. Die vier Aufträge

| Auftrag | Schwerpunkt | Dokumente nach der Analyse |
|---|---|---|
| [A1 – Altlasten und Funktionsschutz](assignments/A1.md) | Echte Löschkandidaten, aktive Loops erhalten, TUI/Extension abgrenzen, Tests zuordnen. | `results/A1/analysis.md`, `contracts.md`, `implementation-plan.md`, `handoff.md` |
| [B1 – Core und Interfaces](assignments/B1.md) | K01–K03, Pi-Kopplungen, Medienzustellung, kleinster brauchbarer K07-Anschluss. | dieselben vier Dateinamen unter `results/B1/` |
| [C1 – Plugins und Paketpiloten](assignments/C1.md) | Web Search, VS Code Web, schwieriger Tool-/Auth-Fall und Web Annotations als K07-Anbieter. | dieselben vier Dateinamen unter `results/C1/` |
| [D1 – Attachments, Web und Workflows](assignments/D1.md) | K04/K05/K07, persistente JSON-Drafts, Grid, Kopieren, Senden und spätere Workflow-Trennung. | dieselben vier Dateinamen unter `results/D1/` |

Alle lesen die [gemeinsamen Regeln](01-gemeinsame-regeln.md). Die [Ergebnisvorlage](02-ergebnisvorlage.md) macht die Berichte vergleichbar. [Vorbereitete Startnachrichten](03-startnachrichten.md) zeigen den genauen Text für die spätere Übergabe; sie wurden nicht versendet.

## 3. Gemeinsamer Stand und Ablage

Pibo-Verbindung: **Primary**, Raum `room_3dd92882-ca07-4e83-ad53-1bf0ccedf00c`. Am Host erneut gelesen: Branch `beta/4.0-plugin-system`, Referenz `ece5f18cffe3f96f8f5dd8c241aac1d439c67b9a`. Das bestätigt die Referenz, nicht einen sauberen Arbeitsbaum oder erfolgreiche Tests. Vor dem späteren Start werden HEAD und Dateistand erneut geprüft; bei Änderung wird die gemeinsame Analysebasis ausdrücklich neu festgelegt.

Hostablage relativ zum Arbeitsverzeichnis dieses Raums:

`.pibo/planning/beta4-phase2-20260920/review-r1/`

Diese workspacebezogene Ablage liegt im ignorierten `.pibo/`-Bereich. Sie ist auf dem Host gespeichert, aber nicht eingecheckt und kein neues kanonisches `docs/`-Bundle. Geprüfte Pläne und Berichte werden später durch A/I nach den OKF-Regeln übernommen. Vorhandene Dateien in der übergeordneten Ablage bleiben unberührt; für dieses Paket gilt ausschließlich `review-r1`.

## 4. Nach deiner Freigabe

Der Dispatcher prüft die Eingabedateien und Basis, dokumentiert die Freigabe und erstellt genau vier Sessions im selben Raum. Ein unterstütztes, raumzugelassenes Profil wird dann geprüft, nicht vorab als verfügbar behauptet. Jede erhält nur ihr Briefing, die gemeinsame Grundlage und ihren Ergebnisbereich. Keine weiteren Subagents ohne Folgefreigabe.

Dieser vorgeschaltete Analysevorlauf liest denselben fixierten Commit und schreibt getrennte Berichtsordner. **Dafür werden noch keine neuen Git-Worktrees erzeugt.** Die produktive A1–D1-Vorbereitung und spätere Umbauten erfolgen weiterhin in eigenen, ausdrücklich zugewiesenen Worktrees wie im v3-Plan. Vor deren Beginn braucht es die I0-Prüfung und einen passenden Ausführungsauftrag.

Die Analyse ist vollständig parallel möglich: C beschreibt seinen K07-Verbraucher unabhängig von D. Erst der spätere ausführbare Pilot hat die Voraussetzung **D1 → Integration → C1**. Niemand wartet in dieser Dokumentenrunde auf noch nicht beauftragten Code.

Anschließend lesen wir alle `handoff.md` und die Fachberichte. Befunde gehen mit ID und Fertigkriterium an den zuständigen Owner zurück. Erst nach diesem Review wird die tatsächliche Umsetzung beauftragt; G1 verlangt weiterhin nutzbaren Code und Tests.

## 5. Was du mit diesem Paket freigeben würdest

Vier reine Analysen mit den genannten Lese- und Schreibgrenzen und genau benannten Ergebnissen. **Nicht freigegeben:** Produktänderungen, Löschungen, neue Abhängigkeiten, Paketinstallation, Worktree-Erstellung, Builds, Provideraufrufe, Gatewayänderungen, Deployments oder Release.

Geschützt bleiben beide Loop-Modi, Browser-IDE als Plugin, normale CLI, feste Core-Ansichten, Sessions, Historie, Daten, Auth-Scope und Runtime-Fähigkeiten. K07 bedeutet ausschließlich Attachments; ein zusätzlicher MCP-/WebMCP-/Tool-Layer bleibt ausgeschlossen.

## 6. Umfang der bereitgestellten Kopien

Auf dem Host liegen die vier Briefings, gemeinsame Regeln, Ergebnisvorlage, Startnachrichten und Freigabestatus sowie der vollständige v3-Markdown-Plan und die drei Original-Skilltexte. `AGENTS.md`, `GLOSSARY.md` und `DESIGN.md` lesen die Worker aus dem bestehenden Repository. Das Downloadpaket enthält zusätzlich die HTML-Präsentation, den Skill-Quellenanhang und eine Kopie des hochgeladenen `DESIGN.md`. Diese Zusatzkopien sind keine Voraussetzung des Analyseauftrags und werden nicht als bereits hostseitig gespeicherte Dateien behauptet.

Die lokale Originalkopie des v3-Plans hat SHA-256 `1d8f923b09b241a88ae0449d81a4cc204c485c7ac0522f87c66de6daa1633d18`. Ein hostseitiger vollständiger Byte-/Hashvergleich steht noch aus; direkte Schreibmeldungen und Rücklesestichproben sind kein kryptografischer Gleichheitsnachweis. Die Integritätsprüfung vor einem späteren Dispatch ist Bestandteil der Startprüfung.
